export class CarreraDto {
  id: number;
  nombre: string;
  numeroSemestres: number;
  descripcion?: string;
}
