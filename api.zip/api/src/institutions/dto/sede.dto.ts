export class SedeDto {
  id: number;
  nombre: string;
  ciudad: string;
  direccion?: string;
  telefono?: string;
  activa: boolean;
}
